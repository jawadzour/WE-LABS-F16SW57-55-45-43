<?php
class Products extends DB {

	public function  getAllProducts(){
		$sql =  "Select * from product ";
		$result = $this->connect()->query($sql);
		$numRows = $result->num_rows;
		if($numRows > 0){
			while($row = $result->fetch_assoc()){
				$data[] = $row;
			}
			return $data;
		}
	}
	
	public function PopulateData($id){
		echo $id;
		$sql = "Select * from product where prod_id=". $id;
		$result = $this->connect()->query($sql);
		
		$getRow = mysqli_fetch_assoc($result);
		return $getRow;
	}
	
	public function insertRecord($pname, $price){
		$sql= "insert into product(prod_name,prod_price) values('". $pname ."','". $price ."')";
		$result  = $this->connect()->query($sql) or die("Operation Failed");
		echo " row inserted";
		
	}
	
	public function deleteRecord ($id){
		$sql = "delete from product where prod_id =". $id;
		$result = $this->connect()->query($sql) or die ("Delete Operatio Faild");
		echo "row deleted";
	}
	
	public function updateRecord($id,$pname,$price){
		$sql = "update product set prod_name ='".$pname.", prod_price=". $price ." where prod_id =". $id;
		$result = $this->connect()->query($sql) or die("update Record failed" . $this->connect()->error);
		echo "row updated";
		
	}
	
	public function multiInsert(){
		$sql= "insert into product(prod_name,prod_price) values('Fridge','50000');";
		$sql.= "insert into product(prod_name,prod_price) values('Dish Waher','50000');";
		$sql.= "insert into product(prod_name,prod_price) values('Iron','50000');";
		
		$result = $this->connect()->multi_query($sql) or die("Multi insert Operation failed");
	}
	
}
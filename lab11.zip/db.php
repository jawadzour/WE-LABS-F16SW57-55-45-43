<?php
class DB {
	protected $db_name = 'test';
	protected $db_user = 'root';
	protected $db_pass = '';
	protected $db_host = 'localhost';

	public function connect(){
		$conn = new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_name);
		if($conn->connect_error){
			die("connection Failed:". $conn->connect_error);
			
		}
		
		return $conn;
		
	}
}
<?php 
	include "db.php";
	include "products.php";
	$products = new Products();
	
	$pname = "";
	$price ="";
	if(isset($_GET['delete'])){
		$id = $_GET['delete'];
		$products->deleteRecord($id);
		header('Location: index.php');
	}
	if(isset($_POST['save'])){
		$pname = $_POST['pname'];
		$price = $_POST['price'];
		$products->insertRecord($pname, $price);
		header('Location: index.php');
	}
	
	if(isset($_GET['edit'])){
		$id = $_GET['edit'];
		$dat = $products->PopulateData($id);
		$pname = $dat['prod_name'];
		$price = $dat['prod_price'];
	}
	
	if(isset($_POST['update'])){
		$id = $_POST[''];
		$pname = $_POST['pname'];
		$price = $_POST['price']; 
		$products->updateRecord($id,$pname, $price);
		header('Location: index.php');
	}
	//insert data
	//$products->insertRecord();
	//update record
	//
	//delete record
	//$products->deleteRecord(5);
	//multi insert
	//$products->multiInsert();
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	</head>
	<body>

	<div class="container">
	<form action="index.php" method="POST">
	  <div class="form-group">
		<label for="exampleInputEmail1">Product name</label>
		<input type="text" class="form-control" value="<?= $pname?>" name="pname" >
		
	  </div>
	  <div class="form-group">
		<label for="exampleInputPassword1">Product Price</label>
		<input type="number" class="form-control"  value="<?= $price ?>" name="price"id="exampleInputPassword1">
	  </div>
	  <?php 
		if(isset($_GET['edit'])){
	  ?>
	  <button type="submit" name="update" class="btn btn-info">Update</button>
		<?php } else {?>
	  <button type="submit" name="save" class="btn btn-primary">Save</button>
		<?php } ?>
</form>
	
	
	<table class="table mt-5">
  <thead>
    <tr>
      <th scope="col">Product Id</th>
      <th scope="col">Product Name</th>
      <th scope="col">Product Price</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
  <?php
		
		$datas = $products->getAllProducts(); 
		foreach($datas as $data){
			
		
  ?>
    <tr>
      <td><?= $data['prod_id']; ?>   </td>
      <td><?= $data['prod_name']; ?> </td>
      <td><?= $data['prod_price']; ?></td>
		<td><a href="index.php?edit=<?=$data['prod_id']; ?> " class="btn btn-info" name="edit">Edit</a> <a href="index.php?delete=<?= $data['prod_id'] ?> " class="ml-1 btn btn-danger" >Delete</a></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
	</div>
	</body>
</html>
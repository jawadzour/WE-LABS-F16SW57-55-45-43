<?php

	if(isset($_GET['delete'])){
		$id = $_GET['delete'];
		$sql = "delete from product where prod_id =". $id;
		$db = new DB();
		
		$result = $db->connect()->query($sql) or die ("Delete Operatio Faild");
		header('Location: index.php');
	}

?>
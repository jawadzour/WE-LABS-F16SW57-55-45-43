<?php
header('Location: http://sw.muet.edu.pk');
?>
<?php
	echo "Tommorow i will learn something new<br>";
	echo "This is bad command: del c:\*.*\$";
	
?>
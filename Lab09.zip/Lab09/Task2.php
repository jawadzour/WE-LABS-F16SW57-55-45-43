<?php

for($i=1;$i<8;$i++){
	for($j=1;$j<8;$j++){
		echo $i*$j." ";
	}
	echo "<br>";
}

?>